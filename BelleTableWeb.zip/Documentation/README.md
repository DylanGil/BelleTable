Bienvenue sur la documentation de BelleTable Desktop vous retrouverez dans ce dossier 5 document :

document1_Prestataire.pdf -> information sur le prestataire
document2_Client.pdf -> information sur le client
document3_devis.pdf -> le devis
document4_contenuesql.pdf -> images de la base de données

Pour récupérer la base de données en local aller dans le dossier ../BDD et récupéré le dossier BelleTableWeb.sql

Pour tester le site web en ligne rendez vous sur : https://pnathan.dev/projets/BelleTable/


<section id="contact"> <!-- sert egalement de footer-->
	<div class="wrapper">
		<h3>Plus d'informations</h3>
		<p>Adresse : 20, rue de la gare 75100 Paris.<br> N° de téléphone : 01 75 02 77 14. <br> Adresse Mail: contact@belletable.eu</p> 
		<br><br>

		<h1>BelleTable<span class="orange">.</span></h1>
		<div class="copyright">Copyright © Tous droits réservés.</div>
	</div>
</section>
<style type="text/css">.lien-footer{color: #007bff;}</style>
<div class="footer">
	<center>
		<h6>
			<i class="far fa-copyright"></i> Copyright <a class="lien-footer" href="">BelleTable.eu</a>
		</h6>
	</center>
</div>